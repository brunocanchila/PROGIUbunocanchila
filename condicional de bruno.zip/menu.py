def menu():
    print("1)persona")
    print("2)vehiculo")
    print("3)universidad")
    print("4)notas")
    print("5)salir")
    
    x = 1
    
    elegir = int(input("selecione una opcion:"))
    if elegir == 1:
        print("has selecionado persona")
    
    elif elegir == 2:
        print("has selecionado vehiculo")
    
    elif elegir == 3:
        print("has selecionado universidad")
    
    elif elegir == 4:
        print("has selecionado notas")
        
    elif elegir == 5:
        print("has salido")
        
    elif (elegir !=1 or 2 or 3 or 4 or 5):
        print("la opcion selecionada no es valida")    
        
menu()         
                      
       
    
 